/*:
 Send messages to the always-on live view using `send()` api of `Messenger` class and explore the code in the UserModule.
 */

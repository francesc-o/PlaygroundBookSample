//
//  Messenger.swift
//  PlaygroundBook
//

import PlaygroundSupport

public struct Messenger {
    
    public static func send(_ mood: Mood) {
        guard let remoteView = PlaygroundPage.current.liveView as? PlaygroundRemoteLiveViewProxy else {
            fatalError("Always-on live view not configured in this page's LiveView.swift.")
        }
        remoteView.send(.integer(mood.rawValue))
    }
}

//
//  MoodViewController.swift
//  PlaygroundBook
//

import UIKit
import PlaygroundSupport

class MoodViewController: UIViewController {
    
    private let label = UILabel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupLabel()
    }
    
    private func setupLabel() {
        label.font = .boldSystemFont(ofSize: 160)
        label.text = Storage.load().label
        label.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(label)
        label.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        label.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
    }
    
    private func updateLabel(_ mood: Mood) {
        self.label.text = mood.label
    }
}

extension MoodViewController: PlaygroundLiveViewMessageHandler {
    
    public func receive(_ message: PlaygroundValue) {
        switch message {
        case let .integer(value):
            guard let mood = Mood(rawValue: value) else {
                return
            }
            updateLabel(mood)
            Storage.save(mood)
        default:
            break
        }
    }
}

//
//  Configurator.swift
//  PlaygroundBook
//

import PlaygroundSupport

public struct Configurator {
    
    // The api called in LiveView.swift to set the always-on live view
    public static func setup() {
        PlaygroundPage.current.needsIndefiniteExecution = true
        PlaygroundPage.current.setLiveView(MoodViewController())
    }
}

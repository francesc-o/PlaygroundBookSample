//
//  Mood.swift
//  PlaygroundBook
//

import Foundation

public enum Mood: Int {
    
    case happy, average, sad
    
    var label: String {
        switch self {
        case .happy: return "😃"
        case .average: return "😐"
        case .sad: return "😕"
        }
    }
}

extension Mood: CustomPlaygroundDisplayConvertible {
    public var playgroundDescription: Any {
        label
    }
}

//
//  Storage.swift
//  PlaygroundBook
//

import PlaygroundSupport

struct Storage {
    
    static let key = "mood"
    
    static func save(_ mood: Mood) {
        PlaygroundKeyValueStore.current[Storage.key] = .integer(mood.rawValue)
    }
    
    static func load() -> Mood {
        guard let storedValue = PlaygroundKeyValueStore.current[Storage.key],
            case .integer(let value) = storedValue,
            let mood = Mood(rawValue: value) else {
                return .average
        }
        return mood
    }
}
